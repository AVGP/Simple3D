/**
* Simple3D
* Basic, cross-platform 3D-Engine
* (c)2010 by M.Naumann
* Licenced under GPL 2!
*/

#include "S3DPrimitive.h"

unsigned int S3DPrimitive::id_max = 1;

/*
virtual void S3DPrimitive::draw(Display *disp,Window w, GC g)
{}

void S3DPrimitive::destroy()
{}

void S3DPrimitive::fill()
{}
*/
