/**
* Simple3D
* Basic, cross-platform 3D-Engine
* (c)2010 by M.Naumann
* Licenced under GPL 2!
*/

#ifndef _S3DGLOBAL_
#define _S3DGLOBAL_

#include <windows.h>
#include "types.h"

#define PI 3.14159
//#define RGB(r,g,b) ((r << 16) | (g << 8) | b)
#define PLANAR_DISTANCE 300

#endif
